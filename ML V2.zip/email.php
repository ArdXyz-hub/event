<?php 
$emailku = "emailkamu@gmail.com";
?>